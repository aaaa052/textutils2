
import './App.css';
// import About from './Component/About';
import Navbar from './Component/Navbar';
import TextForm from './Component/TextForm';

function App() {
  return (
    <>
      
      <Navbar title="TextUtils"/>
       <div className='container'><TextForm heading="Enter the text"/></div> 
      <div className='container'>
      {/* <About/> */}
      </div>
      
      
    </>
  );
}

export default App;
